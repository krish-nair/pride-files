import React, { Component } from "react";

export class About extends Component {
  render() {
    return (
      <div>
        <h1>About Page...</h1>
        <p>
          Lorem ipsum dolor sit, amet consectetur adipisicing elit. Recusandae
          adipisci perspiciatis temporibus provident, alias, delectus in illo
          blanditiis odio nobis, asperiores mollitia! Tenetur vel ipsam
          sapiente, laboriosam debitis adipisci itaque?
        </p>
        <p>
          Lorem ipsum dolor sit, amet consectetur adipisicing elit. Recusandae
          adipisci perspiciatis temporibus provident, alias, delectus in illo
          blanditiis odio nobis, asperiores mollitia! Tenetur vel ipsam
          sapiente, laboriosam debitis adipisci itaque?
        </p>
        <p>
          Lorem ipsum dolor sit, amet consectetur adipisicing elit. Recusandae
          adipisci perspiciatis temporibus provident, alias, delectus in illo
          blanditiis odio nobis, asperiores mollitia! Tenetur vel ipsam
          sapiente, laboriosam debitis adipisci itaque?
        </p>
        <p>
          Lorem ipsum dolor sit, amet consectetur adipisicing elit. Recusandae
          adipisci perspiciatis temporibus provident, alias, delectus in illo
          blanditiis odio nobis, asperiores mollitia! Tenetur vel ipsam
          sapiente, laboriosam debitis adipisci itaque?
        </p>
        <p>
          Lorem ipsum dolor sit, amet consectetur adipisicing elit. Recusandae
          adipisci perspiciatis temporibus provident, alias, delectus in illo
          blanditiis odio nobis, asperiores mollitia! Tenetur vel ipsam
          sapiente, laboriosam debitis adipisci itaque?
        </p>
        <p>
          Lorem ipsum dolor sit, amet consectetur adipisicing elit. Recusandae
          adipisci perspiciatis temporibus provident, alias, delectus in illo
          blanditiis odio nobis, asperiores mollitia! Tenetur vel ipsam
          sapiente, laboriosam debitis adipisci itaque?
        </p>
      </div>
    );
  }
}

export default About;
