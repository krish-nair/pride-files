import React, { Component } from "react";
import Button from "@material-ui/core/Button";
import { Tab, Tabs, TabList, TabPanel } from "react-tabs";

class Section4 extends Component {
  render() {
    return (
      <div>
        <div className="container">
          <div className="row">
            <div className="col s12 m12 l12">
              <Tabs defaultIndex={0}>
                <TabList>
                  <Tab>
                    <img
                      src={require("../images/icon/polo-shirt.svg")}
                      alt="t-shirt"
                    />
                    <span>T-Shirt</span>
                  </Tab>
                  <Tab>
                    <img
                      src={require("../images/icon/coffee-cup.svg")}
                      alt="coffeeCup"
                    />
                    <span>Coffee Cup</span>
                  </Tab>
                  <Tab>
                    <img
                      src={require("../images/icon/shopping-bag.svg")}
                      alt="shopping-bag"
                    />
                    <span>Shopping Bag</span>
                  </Tab>
                  <Tab>
                    <img
                      src={require("../images/icon/perfume.svg")}
                      alt="perfume"
                    />
                    <span>Perfume</span>
                  </Tab>
                </TabList>
                <TabPanel>
                  <div className="img-box">
                    <div className="product-images">
                      <div className="image">
                        <img
                          src={require("../images/hoodie.jpg")}
                          alt="hoodie"
                        />
                        <div className="content">
                          <Button
                            variant="contained"
                            size="large"
                            color="secondary"
                          >
                            Customize
                          </Button>
                        </div>
                      </div>
                      <div className="img-hover" />
                      <div className="image">
                        <img
                          src={require("../images/blacky.jpg")}
                          alt="t-shirt"
                        />
                        <div className="content">
                          <Button
                            variant="contained"
                            size="large"
                            color="secondary"
                          >
                            Customize
                          </Button>
                        </div>
                      </div>
                      <div className="image">
                        <img
                          src={require("../images/t-shirt.png")}
                          alt="t-shirt"
                        />
                        <div className="content">
                          <Button
                            variant="contained"
                            size="large"
                            color="secondary"
                          >
                            Customize
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </TabPanel>
                <TabPanel>
                  <div className="img-box">
                    <div className="product-images">
                      <div className="image">
                        <img
                          src={require("../images/coffee.jpg")}
                          alt="coffee-cup"
                        />
                        <div className="content">
                          <Button
                            variant="contained"
                            size="large"
                            color="secondary"
                          >
                            Customize
                          </Button>
                        </div>
                      </div>
                      <div className="img-hover" />
                      <div className="image">
                        <img
                          src={require("../images/coffee.jpg")}
                          alt="coffee-cup"
                        />
                        <div className="content">
                          <Button
                            variant="contained"
                            size="large"
                            color="secondary"
                          >
                            Customize
                          </Button>
                        </div>
                      </div>
                      <div className="image">
                        <img
                          src={require("../images/coffee.jpg")}
                          alt="coffee-cup"
                        />
                        <div className="content">
                          <Button
                            variant="contained"
                            size="large"
                            color="secondary"
                          >
                            Customize
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </TabPanel>
                <TabPanel>
                  <div className="img-box">
                    <div className="product-images">
                      <div className="image">
                        <img
                          src={require("../images/shoppyBag.jpg")}
                          alt="bag"
                        />
                        <div className="content">
                          <Button
                            className="tab-btn"
                            variant="contained"
                            size="large"
                            color="secondary"
                          >
                            Customize
                          </Button>
                        </div>
                      </div>
                      <div className="img-hover" />
                      <div className="image">
                        <img
                          src={require("../images/shoppyBag.jpg")}
                          alt="bag"
                        />
                        <div className="content">
                          <Button
                            variant="contained"
                            size="large"
                            color="secondary"
                          >
                            Customize
                          </Button>
                        </div>
                      </div>
                      <div className="image">
                        <img
                          src={require("../images/shoppyBag.jpg")}
                          alt="bag"
                        />
                        <div className="content">
                          <Button
                            variant="contained"
                            size="large"
                            color="secondary"
                          >
                            Customize
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </TabPanel>
                <TabPanel>
                  <div className="img-box">
                    <div className="product-images">
                      <div className="image">
                        <img
                          src={require("../images/perfume1.jpg")}
                          alt="perfume"
                        />
                        <div className="content">
                          <Button
                            variant="contained"
                            size="large"
                            color="secondary"
                          >
                            Customize
                          </Button>
                        </div>
                      </div>
                      <div className="img-hover" />
                      <div className="image">
                        <img
                          src={require("../images/perfume1.jpg")}
                          alt="perfume"
                        />
                        <div className="content">
                          <Button
                            variant="contained"
                            size="large"
                            color="secondary"
                          >
                            Customize
                          </Button>
                        </div>
                      </div>
                      <div className="image">
                        <img
                          src={require("../images/perfume1.jpg")}
                          alt="perfume"
                        />
                        <div className="content">
                          <Button
                            variant="contained"
                            size="large"
                            color="secondary"
                          >
                            Customize
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </TabPanel>
              </Tabs>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Section4;
