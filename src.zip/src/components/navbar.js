import React from "react";
import DrawerToggleButton from "./drawerToggleButton";
import { Link } from "react-router-dom";

const toolbar = props => {
  let navbarClasses = ["toolbar"];
  if (props.show) {
    navbarClasses = "toolbar scrolled";
  }
  return (
    <div className={navbarClasses}>
      <nav className="toolbar__navigation">
        <div className="toolbar__toggle-button">
          <DrawerToggleButton click={props.drawerClickHandler} />
        </div>
        <div className="toolbar__logo">
          <Link to="/" exact>
            <img
              src={require("../images/prideclothing-logo-6-2.jpg")}
              alt="logo"
            />
          </Link>
        </div>
        <div className="toolbar__navigation-items">
          <ul>
            <li>
              <Link className="nav__text" to="/" exact>
                Home
              </Link>
            </li>
            <li>
              <Link className="nav__text" to="/about" exact>
                About
              </Link>
            </li>
            <li>
              <Link className="nav__text" to="/products" exact>
                Products
              </Link>
            </li>
            <li>
              <Link className="nav__text" to="/ourWork" exact>
                Our Work
              </Link>
            </li>
            <li>
              <Link className="nav__text" to="/contact" exact>
                Contact Us
              </Link>
            </li>
          </ul>
        </div>
        <Link to="/products" className="primary__btn">
          Product Design
        </Link>
      </nav>
    </div>
  );
};

export default toolbar;
