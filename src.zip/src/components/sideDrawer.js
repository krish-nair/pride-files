import React from "react";
import { Link } from "react-router-dom";

const sideDrawer = props => {
  let drawerClasses = ["side-drawer"];
  if (props.show) {
    drawerClasses = "side-drawer open";
  }
  return (
    <div className={drawerClasses}>
      <div>
        <span className="close-btn" onClick={props.click}>
          &times;
        </span>
      </div>
      <ul>
        <li>
          <Link className="nav__text" to="/" onClick={props.click} exact>
            Home
          </Link>
        </li>
        <li>
          <Link className="nav__text" to="/about" onClick={props.click} exact>
            About
          </Link>
        </li>
        <li>
          <Link
            className="nav__text"
            to="/products"
            onClick={props.click}
            exact
          >
            Products
          </Link>
        </li>
        <li>
          <Link className="nav__text" to="/ourWork" onClick={props.click} exact>
            Our Work
          </Link>
        </li>
        <li>
          <Link className="nav__text" to="/contact" onClick={props.click} exact>
            Contact Us
          </Link>
        </li>
      </ul>
    </div>
  );
};

export default sideDrawer;
