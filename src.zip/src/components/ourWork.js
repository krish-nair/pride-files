import React, { Component } from "react";

export class OurWork extends Component {
  render() {
    return (
      <div>
        <h1>Our-Work Page...</h1>
      </div>
    );
  }
}

export default OurWork;
