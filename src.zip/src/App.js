import React, { Component } from "react";
import "./App.css";
import Home from "./components/home";
import About from "./components/about";
import Products from "./components/products";
import OurWork from "./components/ourWork";
import Contact from "./components/contact";
import Navbar from "./components/navbar";
import SideDrawer from "./components/sideDrawer";
import Footer from "./components/footer";
import { BrowserRouter, Switch, Route } from "react-router-dom";

class App extends Component {
  state = {
    sideDrawerOpen: false,
    scrolled: false
  };

  componentDidMount() {
    window.addEventListener("scroll", () => {
      const isTop = window.scrollY < 100;
      if (isTop !== true) {
        this.setState({
          scrolled: true
        });
      } else
        this.setState({
          scrolled: false
        });
    });
  }

  drawerToggleClickHandler = () => {
    this.setState(prevState => {
      return { sideDrawerOpen: !prevState.sideDrawerOpen };
    });
  };

  sideDrawerClickHandler = () => {
    this.setState({ sideDrawerOpen: false });
  };
  render() {
    let sideDrawer;
    if (this.state.sideDrawerOpen) {
      sideDrawer = (
        <SideDrawer
          click={this.sideDrawerClickHandler}
          show={this.state.sideDrawerOpen}
        />
      );
    }
    return (
      <BrowserRouter>
        <div style={{ height: "100%" }}>
          <Navbar
            drawerClickHandler={this.drawerToggleClickHandler}
            show={this.state.scrolled}
          />
          {sideDrawer}
          <Switch>
            <Route exact path="/" component={Home} />
            <Route exact path="/about" component={About} />
            <Route exact path="/products" component={Products} />
            <Route exact path="/ourwork" component={OurWork} />
            <Route exact path="/contact" component={Contact} />
          </Switch>
          <Footer />
        </div>
      </BrowserRouter>
    );
  }
}

export default App;
